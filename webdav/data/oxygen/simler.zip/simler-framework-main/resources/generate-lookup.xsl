<?xml version="1.0" encoding="UTF-8"?>
<xsl:transform xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    exclude-result-prefixes="#all"
    expand-text="true"
    version="3.0">
    
    <xsl:param name="type" select="'all'"/>
    
    <xsl:variable name="sheetID" select="'1kpE18UQIxis2mnaJMmgftDj0SN3qGzV5qqGwSFjUOl8'"/>
    <xsl:variable name="result-path" select="document-uri(.) => replace('generate-lookup.xsl','')"/>
    
    <xsl:template match="/">
        
        <xsl:if test="$type = 'person' or $type = 'all'">
            <xsl:variable name="result" select="unparsed-text-lines('https://docs.google.com/a/google.com/spreadsheets/d/'||$sheetID||'/gviz/tq?tqx=out:csv&amp;sheet=Personen')"/>
            <xsl:variable name="list">
                <ul type="persons">
                    <xsl:for-each select="$result[position() gt 1]">
                        <xsl:sort select="tokenize(.,'&quot;')[4]"/>
                        <xsl:variable name="id" select="tokenize(.,'&quot;')[2]"/>
                        <xsl:variable name="label" select="tokenize(.,'&quot;')[4]"/>
                        <xsl:if test="matches($id,'\d\d\d') and $label!='' and $label!=',  (-)'">
                            <li id="{$id}" val="{$label}"/> 
                        </xsl:if>
                    </xsl:for-each>
                </ul>
            </xsl:variable>
            
            <xsl:result-document href="{$result-path||'lookup-person.xml'}" method="xml" indent="no">
                <xsl:copy-of select="$list"/>
            </xsl:result-document>
            
            <xsl:message expand-text="yes">✅ {count($list//*:li)} Personeneinträge aus dem Google Sheet gespeichert</xsl:message>
        </xsl:if>
        
        <xsl:if test="$type = 'place' or $type = 'all'">
            <xsl:variable name="result" select="unparsed-text-lines('https://docs.google.com/a/google.com/spreadsheets/d/'||$sheetID||'/gviz/tq?tqx=out:csv&amp;sheet=Orte')"/>
            <xsl:variable name="list">
                <ul type="places">
                    <xsl:for-each select="$result[position() gt 1]">
                        <xsl:sort select="tokenize(.,'&quot;')[4]"/>
                        <xsl:variable name="id" select="tokenize(.,'&quot;')[2]"/>
                        <xsl:variable name="label" select="tokenize(.,'&quot;')[4]"/>
                        <xsl:if test="matches($id,'\d\d\d') and $label!=''">
                            <li id="{$id}" val="{$label}"/> 
                        </xsl:if>
                    </xsl:for-each>
                </ul>
            </xsl:variable>
            
            <xsl:result-document href="{$result-path||'lookup-place.xml'}" method="xml" indent="no">
                <xsl:copy-of select="$list"/>
            </xsl:result-document>
            
            <xsl:message expand-text="yes">✅ {count($list//*:li)} Orteeinträge aus dem Google Sheet gespeichert</xsl:message>
        </xsl:if>
        
        <xsl:if test="$type = 'org' or $type = 'all'">
            <xsl:variable name="result" select="unparsed-text-lines('https://docs.google.com/a/google.com/spreadsheets/d/'||$sheetID||'/gviz/tq?tqx=out:csv&amp;sheet=Institutionen')"/>
            <xsl:variable name="list">
                <ul type="org">
                    <xsl:for-each select="$result[position() gt 1]">
                        <xsl:sort select="tokenize(.,'&quot;')[4]"/>
                        <xsl:variable name="id" select="tokenize(.,'&quot;')[2]"/>
                        <xsl:variable name="label" select="tokenize(.,'&quot;')[4]"/>
                        <xsl:if test="matches($id,'\d\d\d') and $label!=''">
                            <li id="{$id}" val="{$label}"/> 
                        </xsl:if>
                    </xsl:for-each>
                </ul>
            </xsl:variable>
            
            <xsl:result-document href="{$result-path||'lookup-org.xml'}" method="xml" indent="no">
                <xsl:copy-of select="$list"/>
            </xsl:result-document>
            
            <xsl:message expand-text="yes">✅ {count($list//*:li)} Institutioneneinträge aus dem Google Sheet gespeichert</xsl:message>
        </xsl:if>
        
        <xsl:if test="$type = 'bibl' or $type = 'all'">
            <xsl:variable name="result" select="unparsed-text-lines('https://docs.google.com/a/google.com/spreadsheets/d/'||$sheetID||'/gviz/tq?tqx=out:csv&amp;sheet=Werke')"/>
            <xsl:variable name="list">
                <ul type="bibl">
                    <xsl:for-each select="$result[position() gt 1]">
                        <xsl:sort select="tokenize(.,'&quot;')[4]"/>
                        <xsl:variable name="id" select="tokenize(.,'&quot;')[2]"/>
                        <xsl:variable name="label" select="tokenize(.,'&quot;')[4]"/>
                        <xsl:if test="matches($id,'\d\d\d') and $label!=''">
                            <li id="{$id}" val="{$label}"/> 
                        </xsl:if>
                    </xsl:for-each>
                </ul>
            </xsl:variable>
            
            <xsl:result-document href="{$result-path||'lookup-bibl.xml'}" method="xml" indent="no">
                <xsl:copy-of select="$list"/>
            </xsl:result-document>
            
            <xsl:message expand-text="yes">✅ {count($list//*:li)} Werkeinträge aus dem Google Sheet gespeichert</xsl:message>
        </xsl:if>         

        <xsl:if test="$type = 'helvetism' or $type = 'all'">
            <xsl:variable name="result" select="unparsed-text-lines('https://docs.google.com/a/google.com/spreadsheets/d/'||$sheetID||'/gviz/tq?tqx=out:csv&amp;sheet=Helvetismen')"/>
            <xsl:variable name="list">
                <ul type="bibl">
                    <xsl:for-each select="$result[position() gt 1]">
                        <xsl:sort select="tokenize(.,'&quot;')[4]"/>
                        <xsl:variable name="id" select="tokenize(.,'&quot;')[2]"/>
                        <xsl:variable name="label" select="tokenize(.,'&quot;')[4]"/>
                        <xsl:if test="matches($id,'\d\d\d') and $label!=''">
                            <li id="{$id}" val="{$label}"/> 
                        </xsl:if>
                    </xsl:for-each>
                </ul>
            </xsl:variable>
            
            <xsl:result-document href="{$result-path||'lookup-helvetism.xml'}" method="xml" indent="no">
                <xsl:copy-of select="$list"/>
            </xsl:result-document>
            
            <xsl:message expand-text="yes">✅ {count($list//*:li)} Helvetismuseinträge aus dem Google Sheet gespeichert</xsl:message>
        </xsl:if>     
        
    </xsl:template>
    
</xsl:transform>